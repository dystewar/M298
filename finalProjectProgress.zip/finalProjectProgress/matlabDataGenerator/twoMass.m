clc
clear
close all

dt = 0.001;
t = 0:dt:20;
t = t';
kmean = 1.9708;
k = linspace(1,0,length(t));
k = kmean*k;
m = 4.6006;
u = 2*ones(length(t),1);
x0 = [10*rand(1)-5,3*rand(1)-3,0,0];

for i = 1:length(t)
    if i == 1
        x(:,i) = x0';
    else
        x(:,i) = x(:,i-1) + dxdt(:,i-1)*dt;
    end
    dxdt(1,i) = x(2,i);
    dxdt(2,i) = -k(i)/m*(x(1,i)-x(3,i)) + u(i)/m;
    dxdt(3,i) = x(4,i);
    dxdt(4,i) = -k(i)/m*x(3,i) - k(i)/m*(x(3,i)-x(1,i));
end

y = x(3,:)' + sqrt(0.05)*randn(length(t),1);

figure
hold on
plot(t,y);
grid minor

% csvwrite('testData.csv',vertcat(0,y(1:1000:end)));
% csvwrite('testDataParams.csv',[kmean m x0]);
