clc
clear
close all

t = 0:0.001:20;
t = t';
k = 1.9708;
m = 4.6006;
u = 5*ones(length(t),1);
x0 = [5,-1,0,0,0,0,0,0];

A = [ 0  1     0  0     0  0     0  0; 
    -k/m 0    k/m 0     0  0     0  0; 
      0  0     0  1     0  0     0  0; 
     k/m 0 -2*k/m 0    k/m 0     0  0; 
      0  0     0  0     0  1     0  0; 
      0  0    k/m 0 -2*k/m 0    k/m 0;
      0  0     0  0     0  0     0  1;
      0  0     0  0    k/m 0 -2*k/m 0];
B = [0  1/m    0  0     0  0     0  0]';
C = [0   0     0  0     0  0     1  0];
D = 0;
sys = ss(A,B,C,D);

[y,~,x] = lsim(sys,u,t,x0);
y = y + sqrt(0.05)*randn(length(t),1);

figure
hold on
plot(t,y);
grid minor

csvwrite('testData.csv',vertcat(0,y(1:100:end)));
csvwrite('testDataParams.csv',[k m]);
