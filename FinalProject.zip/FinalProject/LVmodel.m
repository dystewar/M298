clc
clear
close all

data = readtable("../STJuliaIntroBayesian-main/data/lv_pop_data.csv");
p = [1.1, 0.5, 0.1, 0.2];
u0 = [1 1];
t = 0:0.01:40;
dt = 0.01;
for i = 1:length(t)
    if i == 1
        x(:,1) = u0';
    else
        x(:,i) = x(:,i-1) + dt*xdot;
    end
    xdot(1,1) = (p(1) - x(2,i)*p(2))*x(1,i);
    xdot(2,1) = (x(1,i)*p(3) - p(4))*x(2,i);
end

figure
plot(t,x);
plot(0:2:)
% csvwrite('LOKVOLMODEL.csv',[x(:,1:200:end)']);
