clc
clear
close all

t = 0:0.001:20;
t = t';
k = 1.9708;
m = 4.6006;
u = 5*ones(length(t),1);
x0 = [5,-1];

A = [0 1; -k/m 0];
B = [0 1/m]';
C = [1 0];
D = 0;
sys = ss(A,B,C,D);

[~,~,x] = lsim(sys,u,t,x0);

figure
hold on
plot(t,x);
grid minor

csvwrite('testData.txt',vertcat([-1,-1],x(1:100:end,:)));
csvwrite('testDataParams.csv',[m k]);
